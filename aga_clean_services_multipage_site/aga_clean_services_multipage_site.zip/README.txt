AGA Clean Services — Multi-Page Website Template

Files:
- index.html
- services.html
- prices.html
- about.html
- reviews.html
- contact.html
- styles.css

How to use:
1. Upload all files into the same website folder.
2. Open index.html as the homepage.
3. Keep styles.css in the same folder as all HTML files.
4. Replace placeholder prices, reviews, phone, email and service details.
5. Connect the contact form to your website form plugin, hosting provider, or email service.

Navigation:
Home | Services | Prices | About | Reviews | Contact
